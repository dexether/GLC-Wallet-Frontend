<?php

namespace App\Http\Controllers;
use App\Models\WalletAddress;
use App\Models\TradeCurrency;
use Illuminate\Http\Request;
use App\Models\Exchange;
use App\Models\Setting;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;

class DashboardController extends Controller
{
    public function index()
    {
       $user_id = Sentinel::getUser()->id;
       $trade_cur = WalletAddress::where('user_id',$user_id)->get();

        $buy_fees = 5;  
      	$sell_fees = 2;
      	$aed_rate =Setting::where('setting_key','aed_rate')->first()->setting_value;
   
      	$exchange_data = Exchange::where('user_id',$user_id)->get();
     
    	return view('exchange.dashboard',compact('buy_fees','sell_fees','trade_cur','exchange_data','aed_rate'));
    }
}
