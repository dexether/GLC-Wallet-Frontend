<?php

namespace App\Http\Controllers;

use App\Events\DepositReceived;
use App\Helpers\GeneralHelper;
use App\Models\Exchange;
use App\Models\User;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Laracasts\Flash\Flash;

class ExchangeController extends Controller
{
    public function __construct()
    {
        $this->middleware(['sentinel','verify_requirements']);
    }

    public function buy()
    {
        $buy_data = Exchange::where(array('side' =>'buy'))->orderBy('id', 'DESC')->get();
        return view('exchange.buy', compact('buy_data'));
    }
      public function sell()
    {
        $sell_data = Exchange::where(array('side' =>'sell'))->orderBy('id', 'DESC')->get();
        return view('exchange.sell', compact('sell_data'));
    }

    public function call_order_middle(Request $request)
    {

        $html="";
        $coin = strtoupper($request->option);
        $user_id = Sentinel::getUser()->id;
        $exgdata = Exchange::where(array('user_id'=>$user_id,'coin'=>$coin))->get();

          if(sizeof($exgdata) >= 1)
        {
                foreach ($exgdata as $exg) 
                {
                    if($exg->status == 0 || $exg->status == 2)
                    {
                         if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                            else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                            else{  } 

                            $total = ($exg->price) * ($exg->same_price);
                            $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                        <td><b>".$exg->side."</b></td>
                                                                        <td>".$exg->order_id."</td>
                                                                        <td>".$exg->coin."</td>
                                                                        <td>".number_format($exg->same_price, 2)."</td>
                                                                        <td>".number_format($exg->price, 2)."</td>
                                                                        <td>".number_format($exg->original_amount, 2)."</td>
                                                                        <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                       <td>";
                                                                       if($exg->status == 0)
                                                                       {  $html.="<label class='label label-warning'>Pending</label>";  }
                                                                       elseif($exg->status == 2)
                                                                       {  $html.="<label class='label label-info'> Partially Pay</label>"; }
                                                                       else
                                                                       {    }
                                                                     $html.="</td></tr>";
                    }
                    else
                    {   }
                }
        }
        else
        {
            $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
        }
            echo $html;die;
    }

    function call_order_full(Request $request)
    {
            $html="";
            $coin = strtoupper($request->option);
            $user_id = Sentinel::getUser()->id;
            $exgdata = Exchange::where(array('user_id'=>$user_id,'coin'=>$coin))->get();

              if(sizeof($exgdata) >= 1)
            {
                    foreach ($exgdata as $exg) 
                    {
                        if($exg->status == 1 || $exg->status == 3)
                        {
                           if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                            else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                            else{  } 

                              $total = ($exg->price) * ($exg->same_price);

                                $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                            <td><b>".$exg->side."</b></td>
                                                                            <td>".$exg->order_id."</td>
                                                                            <td>".$exg->coin."</td>
                                                                            <td>".number_format($exg->same_price, 2)."</td>
                                                                            <td>".number_format($exg->price, 2)."</td>
                                                                            <td>".number_format($exg->original_amount, 2)."</td>
                                                                            <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                           <td>";
                                                                           if($exg->status == 1)
                                                                           {  $html.="<label class='label label-success'>Success</label>";  }
                                                                           elseif($exg->status == 3)
                                                                           {  $html.="<label class='label label-danger'> Cancel </label>"; }
                                                                           else
                                                                           {    }
                                                                         $html.="</td></tr>";
                        }
                        else
                        {   }
                    }
            }
            else
            {
                $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
            }
                echo $html;die;
    }

    function order_full(Request $request)
    {
          $html="";
              $type = $request->option;
              $user_id = Sentinel::getUser()->id;


                if($type == 'bid')
                {
            
                     $exgdata = Exchange::where(array('user_id'=>$user_id))->orderBy('same_price','DESC')->get();
                }
                elseif($type == 'ask')
                {
               
                     $exgdata = Exchange::where(array('user_id'=>$user_id))->orderBy('same_price','ASC')->get();
                }
               else
                {    }

                   if(sizeof($exgdata) >= 1)
                  {
                          foreach ($exgdata as $exg) 
                          {
                              if($exg->status == 1 || $exg->status == 3)
                              {
                                 if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                  else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                  else{  } 

                                    $total = ($exg->price) * ($exg->same_price);

                                      $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                  <td><b>".$exg->side."</b></td>
                                                                                  <td>".$exg->order_id."</td>
                                                                                  <td>".$exg->coin."</td>
                                                                                  <td>".number_format($exg->same_price, 2)."</td>
                                                                                  <td>".number_format($exg->price, 2)."</td>
                                                                                  <td>".number_format($exg->original_amount, 2)."</td>
                                                                                  <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                                 <td>";
                                                                                 if($exg->status == 1)
                                                                                 {  $html.="<label class='label label-success'>Success</label>";  }
                                                                                 elseif($exg->status == 3)
                                                                                 {  $html.="<label class='label label-danger'> Cancel </label>"; }
                                                                                 else
                                                                                 {    }
                                                                               $html.="</td></tr>";
                              }
                              else
                              {   }
                          }
                  }
                  else
                  {
                      $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                  }
                      echo $html;die;
    }


        function order_middle(Request $request)
    {
          $html="";
              $type = $request->option;
              $user_id = Sentinel::getUser()->id;

                if($type == 'bid')
                {
                     $exgdata = Exchange::where(array('user_id'=>$user_id))->orderBy('same_price','DESC')->get();
                }
                elseif($type == 'ask')
                {
               
                     $exgdata = Exchange::where(array('user_id'=>$user_id))->orderBy('same_price','ASC')->get();
                }
               else
                {    }

              if(sizeof($exgdata) >= 1)
              {
                      foreach ($exgdata as $exg) 
                      {
                          if($exg->status == 0 || $exg->status == 2)
                          {
                               if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                  else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                  else{  } 

                                  $total = ($exg->price) * ($exg->same_price);
                                  $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                              <td><b>".$exg->side."</b></td>
                                                                              <td>".$exg->order_id."</td>
                                                                              <td>".$exg->coin."</td>
                                                                              <td>".number_format($exg->same_price, 2)."</td>
                                                                              <td>".number_format($exg->price, 2)."</td>
                                                                              <td>".number_format($exg->original_amount, 2)."</td>
                                                                              <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                             <td>";
                                                                             if($exg->status == 0)
                                                                             {  $html.="<label class='label label-warning'>Pending</label>";  }
                                                                             elseif($exg->status == 2)
                                                                             {  $html.="<label class='label label-info'> Partially Pay</label>"; }
                                                                             else
                                                                             {    }
                                                                           $html.="</td></tr>";
                          }
                          else
                          {   }
                      }
              }
              else
              {
                  $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
              }
                  echo $html;die;

                 
    }


    public function order_full1($coin)
    {
             $html="";
              $user_id = Sentinel::getUser()->id;
              $exgdata = Exchange::where(array('user_id'=>$user_id))->get();
              if(sizeof($exgdata) >= 1)
              {
                      foreach ($exgdata as $exg) 
                      {
                          if($exg->status == 0 || $exg->status == 2)
                          {
                               if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                  else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                  else{  } 

                                  $total = ($exg->price) * ($exg->same_price);
                                  $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                              <td><b>".$exg->side."</b></td>
                                                                              <td>".$exg->order_id."</td>
                                                                              <td>".$exg->coin."</td>
                                                                              <td>".number_format($exg->same_price, 2)."</td>
                                                                              <td>".number_format($exg->price, 2)."</td>
                                                                              <td>".number_format($exg->original_amount, 2)."</td>
                                                                              <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                             <td>";
                                                                             if($exg->status == 0)
                                                                             {  $html.="<label class='label label-warning'>Pending</label>";  }
                                                                             elseif($exg->status == 2)
                                                                             {  $html.="<label class='label label-info'> Partially Pay</label>"; }
                                                                             else {    }
                                                                           $html.="</td></tr>";
                          }
                          else
                          {   }
                      }
              }
              else
              {
                   $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
              }

              print_r($html);
    }

     public function order_middle_1($coin)
    {
                    $html="";
                    $user_id = Sentinel::getUser()->id;
                    $exgdata = Exchange::where(array('user_id'=>$user_id,'coin'=>strtoupper($coin)))->get();

                    if(sizeof($exgdata) >= 1)
                    {
                            foreach ($exgdata as $exg) 
                            {
                                if($exg->status == 0 || $exg->status == 2)
                                {
                                     if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                        else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                        else{  } 

                                        $total = ($exg->price) * ($exg->same_price);
                                        $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                    <td><b>".$exg->side."</b></td>
                                                                                    <td>".$exg->order_id."</td>
                                                                                    <td>".$exg->coin."</td>
                                                                                    <td>".number_format($exg->same_price, 2)."</td>
                                                                                    <td>".number_format($exg->price, 2)."</td>
                                                                                    <td>".number_format($exg->original_amount, 2)."</td>
                                                                                    <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                                   <td>";
                                                                                   if($exg->status == 0)
                                                                                   {  $html.="<label class='label label-warning'>Pending</label>";  }
                                                                                   elseif($exg->status == 2)
                                                                                   {  $html.="<label class='label label-info'> Partially Pay</label>"; }
                                                                                   else
                                                                                   {    }
                                                                                 $html.="</td></tr>";
                                }
                                else
                                {   }
                            }
                    }
                    else
                    {
                        $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                    }
                    echo $html;die;
    }


     public function order_full_1($coin)
    {
                    $html="";
                    $user_id = Sentinel::getUser()->id;
                    $exgdata = Exchange::where(array('user_id'=>$user_id,'coin'=>strtoupper($coin)))->get();

                    if(sizeof($exgdata) >= 1)
                    {
                            foreach ($exgdata as $exg) 
                            {
                                if($exg->status == 1 || $exg->status == 3)
                                {
                                     if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                        else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                        else{  } 

                                        $total = ($exg->price) * ($exg->same_price);
                                        $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                    <td><b>".$exg->side."</b></td>
                                                                                    <td>".$exg->order_id."</td>
                                                                                    <td>".$exg->coin."</td>
                                                                                    <td>".number_format($exg->same_price, 2)."</td>
                                                                                    <td>".number_format($exg->price, 2)."</td>
                                                                                    <td>".number_format($exg->original_amount, 2)."</td>
                                                                                    <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                                   <td>";
                                                                                   if($exg->status == 1)
                                                                                   {  $html.="<label class='label label-success'>Success</label>";  }
                                                                                   elseif($exg->status == 3)
                                                                                   {  $html.="<label class='label label-danger'> Cancel </label>"; }
                                                                                   else
                                                                                   {    }
                                                                                 $html.="</td></tr>";
                                }
                                else
                                {   }
                            }
                    }
                    else
                    {
                        $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                    }
                    echo $html;die;
    }

    public function order_full_block_1($coin)
    {
                    $html="";
                    $user_id = Sentinel::getUser()->id;
                    $exgdata = Exchange::where(array('user_id'=>$user_id,'coin'=>strtoupper($coin)))->get();

                    if(sizeof($exgdata) >= 1)
                    {
                            foreach ($exgdata as $exg) 
                            {
                               if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                        else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                        else{  } 

                                        $total = ($exg->price) * ($exg->same_price);
                                        $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                    <td><b>".$exg->side."</b></td>
                                                                                    <td>".$exg->order_id."</td>
                                                                                    <td>".$exg->coin."</td>
                                                                                    <td>".number_format($exg->same_price, 2)."</td>
                                                                                    <td>".number_format($exg->price, 2)."</td>
                                                                                    <td>".number_format($exg->original_amount, 2)."</td>
                                                                                    <td>".number_format($exg->remaining_amount, 2)."</td>
                                                                                   <td>";
                                                                                   if($exg->status == 1)
                                                                                   {  $html.="<label class='label label-success'>Success</label>"; }
                                                                                  else if($exg->status == 0)
                                                                                  {  $html.="<label class='label label-warning'>Pending</label>";  }
                                                                                   elseif($exg->status == 2)
                                                                                { $html.="<label class='label label-info'> Partially Pay</label>"; }
                                                                                   elseif($exg->status == 3)
                                                                                   {  $html.="<label class='label label-danger'> Cancel </label>"; }
                                                                                   else
                                                                                   {    }
                                                                                 $html.="</td></tr>";
                               
                            }
                    }
                    else
                    {
                        $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                    }
                    echo $html;die;
    }

    public function buy_full_coin_1($coin)
    {
                    $html="";
                    $user_id = Sentinel::getUser()->id;
                    $exgdata = Exchange::where(array('user_id'=>$user_id,'side'=>'buy','coin'=>strtoupper($coin)))->get();

                    if(sizeof($exgdata) >= 1)
                    {
                            foreach ($exgdata as $exg) 
                            {
                               if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                        else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                        else{  } 

                                        $total = ($exg->price) * ($exg->same_price);
                                        $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                    <td><b>1</b></td>
                                                                                    <td>".number_format($exg->price, 2)."</td>
                                                                                     <td>".number_format($total, 2)."</td>
                                                                                    <td>".number_format($exg->same_price, 2)."</td>";
                                                                                 $html.="</tr>";
                               
                            }
                    }
                    else
                    {
                        $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                    }
                    echo $html;die;
    }
    public function sell_full_coin_1($coin)
    {

                    $html="";
                    $user_id = Sentinel::getUser()->id;
                    $exgdata = Exchange::where(array('user_id'=>$user_id,'side'=>'sell','coin'=>strtoupper($coin)))->get();

                    if(sizeof($exgdata) >= 1)
                    {
                            foreach ($exgdata as $exg) 
                            {
                               if($exg->side == 'buy') { $temp_class = '#fbe9e7'; } 
                                        else if($exg->side == 'sell') { $temp_class = '#e8f5e9'; }
                                        else{  } 

                                        $total = ($exg->price) * ($exg->same_price);
                                        $html.="<tr onclick='order_tr_call(1,".$exg->price.",".$total.",".$exg->same_price.")' style='background-color:".$temp_class."'>
                                                                                    <td><b>1</b></td>
                                                                                    <td>".number_format($exg->price, 2)."</td>
                                                                                     <td>".number_format($total, 2)."</td>
                                                                                    <td>".number_format($exg->same_price, 2)."</td>";
                                                                                 $html.="</tr>";
                               
                            }
                    }
                    else
                    {
                        $html.="<tr><td><b style='color:red;'>No Data Found</b></td></tr>";
                    }
                    echo $html;die;
    }



}
